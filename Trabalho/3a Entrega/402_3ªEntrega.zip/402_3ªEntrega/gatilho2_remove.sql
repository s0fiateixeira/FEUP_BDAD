.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

DROP TRIGGER IF EXISTS eventos_sobrepostos;
